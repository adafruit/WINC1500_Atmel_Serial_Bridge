/**
 * \file
 *
 * \brief SAM D20/D21 I2C Master Driver
 *
 * Copyright (C) 2012-2014 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

#ifndef I2C_MASTER_H_INCLUDED
#define I2C_MASTER_H_INCLUDED

#include "i2c_common.h"
#include <sercom.h>
#include <pinmux.h>

#if I2C_MASTER_CALLBACK_MODE == true
#  include <sercom_interrupt.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef PINMUX_DEFAULT
#  define PINMUX_DEFAULT 0
#endif

/**
 * \addtogroup asfdoc_sam0_sercom_i2c_group
 *
 * @{
 */

/** \brief Interrupt flags
 *
 * Flags used when reading or setting interrupt flags.
 */
enum i2c_master_interrupt_flag {
	/** Interrupt flag used for write */
	I2C_MASTER_INTERRUPT_WRITE = 0,
	/** Interrupt flag used for read */
	I2C_MASTER_INTERRUPT_READ  = 1,
};

/**
 * \brief Values for hold time after start bit.
 *
 * Values for the possible I<SUP>2</SUP>C master mode SDA internal hold times after start
 * bit has been sent.
 */
enum i2c_master_start_hold_time {
	/** Internal SDA hold time disabled */
	I2C_MASTER_START_HOLD_TIME_DISABLED = SERCOM_I2CM_CTRLA_SDAHOLD(0),
	/** Internal SDA hold time 50ns-100ns */
	I2C_MASTER_START_HOLD_TIME_50NS_100NS = SERCOM_I2CM_CTRLA_SDAHOLD(1),
	/** Internal SDA hold time 300ns-600ns */
	I2C_MASTER_START_HOLD_TIME_300NS_600NS = SERCOM_I2CM_CTRLA_SDAHOLD(2),
	/** Internal SDA hold time 400ns-800ns */
	I2C_MASTER_START_HOLD_TIME_400NS_800NS = SERCOM_I2CM_CTRLA_SDAHOLD(3),
};

/**
 * \ brief Values for inactive bus time-out.
 *
 * If the inactive bus time-out is enabled and the bus is inactive for
 * longer than the time-out setting, the bus state logic will be set to idle.
 */
enum i2c_master_inactive_timeout {
	/** Inactive bus time-out disabled */
	I2C_MASTER_INACTIVE_TIMEOUT_DISABLED = SERCOM_I2CM_CTRLA_INACTOUT(0),
	/** Inactive bus time-out 5-6 SCL cycle time-out (50-60us) */
	I2C_MASTER_INACTIVE_TIMEOUT_55US = SERCOM_I2CM_CTRLA_INACTOUT(1),
	/** Inactive bus time-out 10-11 SCL cycle time-out (100-110us) */
	I2C_MASTER_INACTIVE_TIMEOUT_105US = SERCOM_I2CM_CTRLA_INACTOUT(2),
	/** Inactive bus time-out 20-21 SCL cycle time-out (200-210us) */
	I2C_MASTER_INACTIVE_TIMEOUT_205US = SERCOM_I2CM_CTRLA_INACTOUT(3),
};

/**
 * \brief I<SUP>2</SUP>C frequencies
 *
 * Values for standard I<SUP>2</SUP>C speeds supported by the module. The driver
 * will also support setting any value between 10 and 100kHz, in which case set
 * the value in the \ref i2c_master_config at desired value divided by 1000.
 *
 * Example: If 10kHz operation is required, give baud_rate in the configuration
 * structure the value 10.
 *
 * \note Max speed is given by GCLK-frequency divided by 10, and lowest is
 *       given by GCLK-frequency divided by 510.
 */
enum i2c_master_baud_rate {
	/** Baud rate at 100kHz (Standard-mode) */
	I2C_MASTER_BAUD_RATE_100KHZ = 100,
	/** Baud rate at 400kHz (Fast-mode) */
	I2C_MASTER_BAUD_RATE_400KHZ = 400,
#ifdef FEATURE_I2C_FAST_MODE_PLUS_AND_HIGH_SPEED
	/** Baud rate at 1MHz (Fast-mode Plus) */
	I2C_MASTER_BAUD_RATE_1000KHZ = 1000,
	/** Baud rate at 3.4MHz (High-speed mode) */
	I2C_MASTER_BAUD_RATE_3400KHZ = 3400,
#endif
};

#if I2C_MASTER_CALLBACK_MODE == true
/**
 * \brief Callback types
 *
 * The available callback types for the I<SUP>2</SUP>C master module.
 */
enum i2c_master_callback {
	/** Callback for packet write complete */
	I2C_MASTER_CALLBACK_WRITE_COMPLETE = 0,
	/** Callback for packet read complete */
	I2C_MASTER_CALLBACK_READ_COMPLETE  = 1,
	/** Callback for error */
	I2C_MASTER_CALLBACK_ERROR          = 2,
#  if !defined(__DOXYGEN__)
	/** Total number of callbacks */
	_I2C_MASTER_CALLBACK_N             = 3,
#  endif
};

#  if !defined(__DOXYGEN__)
/* Prototype for software module. */
struct i2c_master_module;

typedef void (*i2c_master_callback_t)(
		struct i2c_master_module *const module);
#  endif
#endif

/**
 * \brief SERCOM I<SUP>2</SUP>C Master driver software device instance structure.
 *
 * SERCOM I<SUP>2</SUP>C Master driver software instance structure, used to
 * retain software state information of an associated hardware module instance.
 *
 * \note The fields of this structure should not be altered by the user
 *       application; they are reserved for module-internal use only.
 */
struct i2c_master_module {
#if !defined(__DOXYGEN__)
	/** Hardware instance initialized for the struct */
	Sercom *hw;
	/** Module lock */
	volatile bool locked;
	/** Unknown bus state timeout */
	uint16_t unknown_bus_state_timeout;
	/** Buffer write timeout value */
	uint16_t buffer_timeout;
	/** If true, stop condition will be sent after a read/write */
	bool send_stop;
#  if I2C_MASTER_CALLBACK_MODE == true
	/** Pointers to callback functions */
	volatile i2c_master_callback_t callbacks[_I2C_MASTER_CALLBACK_N];
	/** Mask for registered callbacks */
	volatile uint8_t registered_callback;
	/** Mask for enabled callbacks */
	volatile uint8_t enabled_callback;
	/** The total number of bytes to transfer */
	volatile uint16_t buffer_length;
	/**
	 * Counter used for bytes left to send in write and to count number of
	 * obtained bytes in read
	 */
	volatile uint16_t buffer_remaining;
	/** Data buffer for packet write and read */
	volatile uint8_t *buffer;
	/** Save direction of async request. 1 = read, 0 = write */
	volatile enum i2c_transfer_direction transfer_direction;
	/** Status for status read back in error callback */
	volatile enum status_code status;
#  endif
#endif
};

/**
 * \brief Configuration structure for the I<SUP>2</SUP>C Master device
 *
 * This is the configuration structure for the I<SUP>2</SUP>C Master device. It
 * is used as an argument for \ref i2c_master_init to provide the desired
 * configurations for the module. The structure should be initialized using the
 * \ref i2c_master_get_config_defaults .
 */
struct i2c_master_config {
	/** Baud rate for I<SUP>2</SUP>C operations */
	enum i2c_master_baud_rate baud_rate;
	/** GCLK generator to use as clock source */
	enum gclk_generator generator_source;
	/** Bus hold time after start signal on data line */
	enum i2c_master_start_hold_time start_hold_time;
	/** Unknown bus state \ref asfdoc_sam0_sercom_i2c_unknown_bus_timeout "timeout" */
	uint16_t unknown_bus_state_timeout;
	/** Timeout for packet write to wait for slave */
	uint16_t buffer_timeout;
	/** Set to keep module active in sleep modes */
	bool run_in_standby;
	/** PAD0 (SDA) pinmux */
	uint32_t pinmux_pad0;
	/** PAD1 (SCL) pinmux */
	uint32_t pinmux_pad1;
	/** Set to enable SCL low time-out */
	bool scl_low_timeout;
	/** Inactive bus time out */
	enum i2c_master_inactive_timeout inactive_timeout;
#ifdef FEATURE_I2C_SCL_STRETCH_MODE
	/** Set to enable SCL stretch only after ACK bit */
	bool scl_stretch_only_after_ack_bit;
#endif
#ifdef FEATURE_I2C_SCL_EXTEND_TIMEOUT
	/** Set to enable slave SCL low extend time-out */
	bool slave_scl_low_extend_timeout;
	/** Set to enable maser SCL low extend time-out */
	bool master_scl_low_extend_timeout;
#endif
};

/**
 * \name Lock/Unlock
 * @{
 */

/**
 * \brief Attempt to get lock on driver instance
 *
 * This function checks the instance's lock, which indicates whether or not it
 * is currently in use, and sets the lock if it was not already set.
 *
 * The purpose of this is to enable exclusive access to driver instances, so
 * that, e.g., transactions by different services will not interfere with each
 * other.
 *
 * \param[in,out] module Pointer to the driver instance to lock.
 *
 * \retval STATUS_OK if the module was locked.
 * \retval STATUS_BUSY if the module was already locked.
 */
static inline enum status_code i2c_master_lock(
		struct i2c_master_module *const module)
{
	enum status_code status;

	system_interrupt_enter_critical_section();

	if (module->locked) {
		status = STATUS_BUSY;
	} else {
		module->locked = true;
		status = STATUS_OK;
	}

	system_interrupt_leave_critical_section();

	return status;
}

/**
 * \brief Unlock driver instance
 *
 * This function clears the instance lock, indicating that it is available for
 * use.
 *
 * \param[in,out] module Pointer to the driver instance to lock.
 *
 * \retval STATUS_OK if the module was locked.
 * \retval STATUS_BUSY if the module was already locked.
 */
static inline void i2c_master_unlock(struct i2c_master_module *const module)
{
	module->locked = false;
}

/** @} */

/**
 * \name Configuration and Initialization
 * @{
 */

/**
 * \brief Returns the synchronization status of the module
 *
 * Returns the synchronization status of the module.
 *
 * \param[in]  module  Pointer to software module structure
 *
 * \return Status of the synchronization.
 * \retval true   Module is busy synchronizing
 * \retval false  Module is not synchronizing
 */
static inline bool i2c_master_is_syncing (
		const struct i2c_master_module *const module)
{
	/* Sanity check. */
	Assert(module);
	Assert(module->hw);

	SercomI2cm *const i2c_hw = &(module->hw->I2CM);

#ifdef FEATURE_I2C_SYNC_SCHEME_VERSION_2
	return (i2c_hw->SYNCBUSY.reg & SERCOM_I2CM_SYNCBUSY_MASK);
#else
	return (i2c_hw->STATUS.reg & SERCOM_I2CM_STATUS_SYNCBUSY);
#endif
}

#if !defined(__DOXYGEN__)
/**
 * \internal
 * Wait for hardware module to sync
 *
 * \param[in]  module  Pointer to software module structure
 */
static void _i2c_master_wait_for_sync(
		const struct i2c_master_module *const module)
{
	/* Sanity check. */
	Assert(module);

	while (i2c_master_is_syncing(module)) {
		/* Wait for I2C module to sync. */
	}
}
#endif

/**
 * \brief Gets the I<SUP>2</SUP>C master default configurations
 *
 * Use to initialize the configuration structure to known default values.
 *
 * The default configuration is as follows:
 * - Baudrate 100kHz
 * - GCLK generator 0
 * - Do not run in standby
 * - Start bit hold time 300ns-600ns
 * - Buffer timeout = 65535
 * - Unknown bus status timeout = 65535
 * - Do not run in standby
 * - PINMUX_DEFAULT for SERCOM pads
 *
 * \param[out] config  Pointer to configuration structure to be initiated
 */
static inline void i2c_master_get_config_defaults(
		struct i2c_master_config *const config)
{
	/*Sanity check argument. */
	Assert(config);
	config->baud_rate        = I2C_MASTER_BAUD_RATE_100KHZ;
	config->generator_source = GCLK_GENERATOR_0;
	config->run_in_standby   = false;
	config->start_hold_time  = I2C_MASTER_START_HOLD_TIME_300NS_600NS;
	config->buffer_timeout   = 65535;
	config->unknown_bus_state_timeout = 65535;
	config->pinmux_pad0      = PINMUX_DEFAULT;
	config->pinmux_pad1      = PINMUX_DEFAULT;
	config->scl_low_timeout  = false;
	config->inactive_timeout = I2C_MASTER_INACTIVE_TIMEOUT_DISABLED;
#ifdef FEATURE_I2C_SCL_STRETCH_MODE
	config->scl_stretch_only_after_ack_bit = false;
#endif
#ifdef FEATURE_I2C_SCL_EXTEND_TIMEOUT
	config->slave_scl_low_extend_timeout   = false;
	config->master_scl_low_extend_timeout  = false;
#endif
}

enum status_code i2c_master_init(
		struct i2c_master_module *const module,
		Sercom *const hw,
		const struct i2c_master_config *const config);

/**
 * \brief Enables the I<SUP>2</SUP>C module
 *
 * Enables the requested I<SUP>2</SUP>C module and set the bus state to IDLE
 * after the specified \ref asfdoc_sam0_sercom_i2c_timeout "timeout" period if no
 * stop bit is detected.
 *
 * \param[in]  module  Pointer to the software module struct
 */
static inline void i2c_master_enable(
		const struct i2c_master_module *const module)
{
	/* Sanity check of arguments. */
	Assert(module);
	Assert(module->hw);

	SercomI2cm *const i2c_module = &(module->hw->I2CM);

	/* Timeout counter used to force bus state. */
	uint32_t timeout_counter = 0;

	/* Wait for module to sync. */
	_i2c_master_wait_for_sync(module);

	/* Enable module. */
	i2c_module->CTRLA.reg |= SERCOM_I2CM_CTRLA_ENABLE;

#if I2C_MASTER_CALLBACK_MODE == true
	/* Enable module interrupts */
	system_interrupt_enable(_sercom_get_interrupt_vector(module->hw));
#endif
	/* Start timeout if bus state is unknown. */
	while (!(i2c_module->STATUS.reg & SERCOM_I2CM_STATUS_BUSSTATE(1))) {
		timeout_counter++;
		if(timeout_counter >= (module->unknown_bus_state_timeout)) {
			/* Timeout, force bus state to idle. */
			i2c_module->STATUS.reg = SERCOM_I2CM_STATUS_BUSSTATE(1);
			/* Workaround #1 */
			return;
		}
	}
}

/**
 * \brief Disable the I<SUP>2</SUP>C module
 *
 * Disables the requested I<SUP>2</SUP>C module.
 *
 * \param[in]  module  Pointer to the software module struct
 */
static inline void i2c_master_disable(
		const struct i2c_master_module *const module)
{
	/* Sanity check of arguments. */
	Assert(module);
	Assert(module->hw);

	SercomI2cm *const i2c_module = &(module->hw->I2CM);

	/* Wait for module to sync. */
	_i2c_master_wait_for_sync(module);

	/* Disable module. */
	i2c_module->CTRLA.reg &= ~SERCOM_I2CM_CTRLA_ENABLE;

#if I2C_MASTER_CALLBACK_MODE == true
	/* Disable module interrupts */
	system_interrupt_disable(_sercom_get_interrupt_vector(module->hw));
#endif
}

void i2c_master_reset(struct i2c_master_module *const module);

/** @} */

/**
* \name Read and Write
* @{
*/

enum status_code i2c_master_read_packet_wait(
		struct i2c_master_module *const module,
		struct i2c_packet *const packet);

enum status_code i2c_master_read_packet_wait_no_stop(
		struct i2c_master_module *const module,
		struct i2c_packet *const packet);

enum status_code i2c_master_write_packet_wait(
		struct i2c_master_module *const module,
		struct i2c_packet *const packet);

enum status_code i2c_master_write_packet_wait_no_stop(
		struct i2c_master_module *const module,
		struct i2c_packet *const packet);

void i2c_master_send_stop(struct i2c_master_module *const module);

/** @} */

#ifdef FEATURE_I2C_DMA_SUPPORT
/**
* \name SERCOM I2C master with DMA interfaces
* @{
*/

/**
 * \brief Set I2C for DMA transfer with slave address and transfer size.
 *
 * This function will set the slave address, transfer size and enable the auto transfer
 * mode for DMA.
 *
 * \param[in,out] module Pointer to the driver instance to lock.
 * \param[in] addr I2C slave address
 * \param[in] length I2C transfer length with DMA.
 * \param[in] direction I2C transfer direction
 *
 */
static inline void i2c_master_dma_set_transfer(struct i2c_master_module *const module,
		uint16_t addr, uint8_t length, enum i2c_transfer_direction direction)
{
	module->hw->I2CM.ADDR.reg =
		SERCOM_I2CM_ADDR_ADDR(addr<<1) |
		SERCOM_I2CM_ADDR_LENEN |
		SERCOM_I2CM_ADDR_LEN(length) |
		direction;
}

/** @} */
#endif

/** @} */

#ifdef __cplusplus
}
#endif

#endif /* I2C_MASTER_H_INCLUDED */
